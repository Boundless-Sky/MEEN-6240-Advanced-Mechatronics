#ifndef __PosControl__H
#define __PosControl__H

#include <xc.h>                 // processor SFR definitions
#include <sys/attribs.h>        // __ISR macro
#include "encoder.h"
#include "isense.h"
#include "utilities.h"
#include "NU32.h"

void posControl_init(void);


#endif //__PosControl__H