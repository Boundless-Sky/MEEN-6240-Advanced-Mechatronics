#include "NU32.h" // config bits, constants, funcs for startup and UART
// include other header files here
#include "encoder.h"
#include "utilities.h"
#include "isense.h"
#include "currentcontrol.h"
//#include "stdlib.h"

#define BUF_SIZE 200

// Global Variables
volatile int duty_cycle = 0;

// current control variables
volatile float kp_i = 0;
volatile float ki_i = 0;
volatile float actual_current[100];
volatile int ref_current[100];
volatile int count = 0;
volatile int test_mA = 200;
volatile float error, effort, pterm, iterm, ierror = 0, ierror_last = 0;
volatile float i_error_max = 50;

// position control variables
volatile float kp_p = 0;
volatile float ki_p = 0;
volatile float kd_p = 0;

volatile int user_deg = 0;
volatile float err_last = 0; ierr_last = 0, ierr_max = 50, derr_last = 0;
volatile float pos_effort = 0;

// Trajectory tracking variables
#define TRAJ_SIZE 500 //  same length as example trajector in genRef.m
volatile float ref_pos[TRAJ_SIZE];
volatile float actual_pos[TRAJ_SIZE];
int Nsamples = 0;
volatile int cnt = 0;

/***** Interrupt service routines ******/
// using shadow register set since this is called so often
void __ISR(_TIMER_1_VECTOR, IPL6SRS) Timer1ISR(void){ // table 8.1 book
	// SOFT or SRS (only for 1 function and also for pic has to be lvl6)
  // pwm goes to enable or ain2 on breakout *SEE DRV8835 datashee
  // i/o pin goes to phase or ain1
  switch (curr_mode()) { // 0 = IDLE, 1 = PWM, 2 = ITEST, 3 = HOLD, 4 = TRACK
  // see page 444 of pdf book 
    case 0: // idle
    {
      LATDbits.LATD6 = 0; // phase doesn't matter
      OC1RS = 0; // turn off pwm
      duty_cycle = 0;
      break;
    }
    case 1: // pwm
    {
      // if (duty_cycle < 0){
      //   LATDSET = 0x40;//LATDbits.LATD6 = 1; // backwards
      //   duty_cycle = -1*duty_cycle; // make it positive, so don't need to use abs
      // } else {
      //   LATDCLR = 0x40;//LATDbits.LATD6 = 0; // forward
      // }    
      if (duty_cycle < 0){
        LATDCLR = 0x40; // ccw -
        OC1RS = -duty_cycle*0.01*1000; // dutycyle percent/100*PR2
      } 
      if (duty_cycle > 0) {
        LATDSET = 0x40; // cw +
        OC1RS = duty_cycle*0.01*1000; // dutycyle percent/100*PR2
      }
      break;
    }
    case 2: // itest
    {
      // desired +/- 200 mA 100 hz square wave reference current
      // since half cycle of 100 hz isgnal is 5ms and 5 ms at 5000 samples/s
      // is 25 samples that means the reference current toggles every 25 times through
      // the ISR
      /*
      error = setpoint-measured;

      // proportional term
      Tp(n) = P * error(n); 

      // derivative term
      Td(n) = (D*N*(error(n)-error(n-1))) + (Td(n-1) * (1-N*dt));

      //integral term
      i_error(n) = i_error(n-1) + error(n)*dt;
      if (i_error(n)< - i_error_max) i_error(n) = -i_error_max;
      else if (i_error >  i_error_max) i_error(n) = i_error_max;
      Ti = I * i_error(n);

      Effort(n)= Tp +Td +Ti;
      */
      if ((count == 25) || (count == 50) || (count == 75)){
        test_mA = -test_mA;
      }
      ref_current[count] = test_mA;
      actual_current[count] = avg_i_mA();
      error = ref_current[count] - actual_current[count];
      pterm = kp_i * error;
      ierror = ierror_last + error*0.0002; // 5khz = 0.0002
      if (ierror < -i_error_max){
        ierror = -i_error_max;
      }
      else if (ierror > i_error_max){
        ierror = i_error_max;
      }
      ierror_last = ierror;
      iterm = ki_i * ierror;
      effort = pterm + iterm;
      if (effort < 0){
        LATDCLR = 0x40; // ccw -
        OC1RS = -effort*0.01*1000; // dutycyle percent/100*PR2
      } 
      if (effort > 0) {
        LATDSET = 0x40; // cw +
        OC1RS = effort*0.01*1000; // dutycyle percent/100*PR2
      }
      if (count == 99){
        set_mode(0); // current control test is done, idle
        count = 0;
      }
      count = count + 1;
      break;
    }
    case 3: // hold
    {
      error = pos_effort - avg_i_mA();
      pterm = kp_i * error;
      ierror = ierror_last + error*0.0002; // 5khz = 0.0002
      if (ierror < -i_error_max){
        ierror = -i_error_max;
      }
      else if (ierror > i_error_max){
        ierror = i_error_max;
      }
      ierror_last = ierror;
      iterm = ki_i * ierror;
      effort = pterm + iterm;
      if (effort < 0){
        LATDCLR = 0x40; // ccw -
        OC1RS = -effort*0.01*1000; // dutycyle percent/100*PR2
      } 
      if (effort > 0) {
        LATDSET = 0x40; // cw +
        OC1RS = effort*0.01*1000; // dutycyle percent/100*PR2
      }
      break;
    }
    case 4: // track ~ same as hold... :)
    {
      error = pos_effort - avg_i_mA();
      pterm = kp_i * error;
      ierror = ierror_last + error*0.0002; // 5khz = 0.0002
      if (ierror < -i_error_max){
        ierror = -i_error_max;
      }
      else if (ierror > i_error_max){
        ierror = i_error_max;
      }
      ierror_last = ierror;
      iterm = ki_i * ierror;
      effort = pterm + iterm;
      if (effort < 0){
        LATDCLR = 0x40; // ccw -
        OC1RS = -effort*0.01*1000; // dutycyle percent/100*PR2
      } 
      if (effort > 0) {
        LATDSET = 0x40; // cw +
        OC1RS = effort*0.01*1000; // dutycyle percent/100*PR2
      }
      break;
    }
    default: 
    {
      LATDbits.LATD6 = 0; // turn off enable pin
      break;
    }
  }
  /* Test 
  OC1RS = 250; // 25% pwm
  LATDINV = 0x40; // digital output pin D6 turn on off
  */
	IFS0bits.T1IF = 0; // clear flag 
}

// position control 200 hz
void __ISR(_TIMER_3_VECTOR, IPL3SOFT) Timer3ISR(void){
  switch (curr_mode()){ 
    case 3:{ // hold mode
      float err, ppos, ierr, ipos, dpos;
      int N = 100;
      err = user_deg - encoder_deg();
      ppos = kp_p * err;
      ierr = ierr_last + err*0.005; // 200 hz = 0.005
      if (ierr < -ierr_max){
        ierr = -ierr_max;
      }
      else if (ierr > ierr_max){
        ierr = ierr_max;
      }
      ierr_last = ierr;
      ipos = ki_p * ierr;

      dpos = (kd_p*N*(err-err_last)) + (derr_last * (1-N*0.005));
      derr_last = dpos;
      err_last = err;

      pos_effort = ppos + ipos + dpos; //commanded current 
      break;
    }
    case 4: { // track mode
      float err, ppos, ierr, ipos, dpos;
      int N = 100;
      actual_pos[cnt] = encoder_deg();
      err = ref_pos[cnt] - actual_pos[cnt];
      ppos = kp_p * err;
      ierr = ierr_last + err*0.005; // 200 hz = 0.005
      if (ierr < -ierr_max){
        ierr = -ierr_max;
      }
      else if (ierr > ierr_max){
        ierr = ierr_max;
      }
      ierr_last = ierr;
      ipos = ki_p * ierr;

      dpos = (kd_p*N*(err-err_last)) + (derr_last * (1-N*0.005));
      derr_last = dpos;
      err_last = err;

      pos_effort = ppos + ipos + dpos; //commanded current 
      cnt++;
      if (cnt == Nsamples){
        user_deg = ref_pos[cnt - 1];
        cnt = 0;
        set_mode(3); // hold last position
      }
      break;
    }
    
  }
  //LATDINV = 0x80; // test enable in current control.c 
  // to make the pin d7 into analog output , d7 on pic32 breakout
  IFS0bits.T3IF = 0; // clear flag
}

int main() 
{
  char buffer[BUF_SIZE];
  set_mode(0); // Set mode to IDLE
  NU32_Startup(); // cache on, min flash wait, interrupts on, LED/button init, UART init
  NU32_LED1 = 1;  // turn off the LEDs
  NU32_LED2 = 1;        
  __builtin_disable_interrupts();
  // in future, initialize modules or peripherals here
  encoder_init();
  isense_init();
  currControl_init();
  posControl_init();
  encoder_reset();
  __builtin_enable_interrupts();

  while(1)
  {
    NU32_ReadUART3(buffer,BUF_SIZE); // we expect the next character to be a menu command
    NU32_LED2 = 1;                   // clear the error LED
    switch (buffer[0]) {
      case 'a': // Read current sensor (ADC counts)
      {
        sprintf(buffer, "%d\r\n", avg_i_count());
        NU32_WriteUART3(buffer); // send encoder count to client
        break;
      }
      case 'b': // Read current sensor (mA)
      {
        sprintf(buffer, "%f\r\n", avg_i_mA());
        NU32_WriteUART3(buffer); // send encoder count to client
        break;
      }
      case 'c': // read encoder in encoder counts
        {
          encoder_counts(); // dump this, for some reason it keeps it.
          sprintf(buffer, "%d\r\n", encoder_counts());
          NU32_WriteUART3(buffer); // send encoder count to client
          /*Should get  +ccw, -cw in encoder counts*/
          break;
        }
      // case 'd':                      // dummy command for demonstration purposes
      // {
      //   int n = 0;
      //   NU32_ReadUART3(buffer,BUF_SIZE);
      //   sscanf(buffer, "%d", &n);
      //   sprintf(buffer,"%d\r\n", n + 1); // return the number + 1
      //   NU32_WriteUART3(buffer);
      //   break;
      // }
      case 'd': // read encoder in degrees
        {
          sprintf(buffer, "%f\r\n", encoder_deg());
          NU32_WriteUART3(buffer);
          break;
        }
      case 'e': // reset the encoder to "zeroth" position 
        {
          encoder_reset();
          break;
        }
      case 'f': // set PWM (-100 to 100) 
      {
        set_mode(1); // pwm mode
        NU32_ReadUART3(buffer, BUF_SIZE);
        sscanf(buffer, "%d", &duty_cycle);
        // sprintf(buffer, "%d\r\n", duty_cycle);
        // NU32_WriteUART3(buffer);
        break;
      }
      case 'g': // set current gains
      {
        NU32_ReadUART3(buffer, BUF_SIZE);
        sscanf(buffer, "%f", &kp_i);
        NU32_ReadUART3(buffer, BUF_SIZE);
        sscanf(buffer, "%f", &ki_i);
        break;
      }
      case 'h': // get current gains
      {
        sprintf(buffer, "%f\r\n", kp_i);
        NU32_WriteUART3(buffer);
        sprintf(buffer, "%f\r\n", ki_i);
        NU32_WriteUART3(buffer);
        break;
      }
      case 'i': // set position gains
      {
        NU32_ReadUART3(buffer, BUF_SIZE);
        sscanf(buffer, "%f", &kp_p);
        NU32_ReadUART3(buffer, BUF_SIZE);
        sscanf(buffer, "%f", &ki_p);
        NU32_ReadUART3(buffer, BUF_SIZE);
        sscanf(buffer, "%f", &kd_p);
        break;
      }
      case 'j': // get position gains
      {
        sprintf(buffer, "%f\r\n", kp_p);
        NU32_WriteUART3(buffer);
        sprintf(buffer, "%f\r\n", ki_p);
        NU32_WriteUART3(buffer);
        sprintf(buffer, "%f\r\n", kd_p);
        NU32_WriteUART3(buffer);
        break;
      }
      case 'k': // test current control
      {
        set_mode(2); // itest
        while (curr_mode() == 2){}; // wait until test is done
        sprintf(buffer, "%d\r\n", 100); // send number of sampels being sent
        NU32_WriteUART3(buffer);
        int i;
        for (i = 0; i < 100; i++){
          sprintf(buffer, "%d %f\r\n", ref_current[i], actual_current[i]);
          NU32_WriteUART3(buffer);
        }
        break;
      }
      case 'l': // got to angle (deg)
        NU32_ReadUART3(buffer, BUF_SIZE);
        sscanf(buffer, "%d", &user_deg);
        set_mode(3);
        sprintf(buffer, "%d\r\n", user_deg);
        NU32_WriteUART3(buffer);
        break;
      case 'm': // loading step trajectory
      {
        int dump = 0;
        NU32_ReadUART3(buffer, BUF_SIZE);
        sscanf(buffer, "%d", &Nsamples);
        if (Nsamples > TRAJ_SIZE){
          dump = Nsamples - TRAJ_SIZE;
          Nsamples = TRAJ_SIZE;
        }
        int i;
        for (i = 0; i < Nsamples; i++){
          NU32_ReadUART3(buffer, BUF_SIZE);
          sscanf(buffer, "%f", &ref_pos[i]);
        }
        // dump by reading but not saving
        if (dump){ // if dump is true, basically anything not 0
          for (i = 0; i < dump; i++){
            NU32_ReadUART3(buffer, BUF_SIZE);
          }
          dump == 0;
        }
        // testing by sending back what recieved
        // for (i = 0; i < Nsamples; i++){
        //   sprintf(buffer, "%f\r\n", ref_pos[i] );
        //   NU32_WriteUART3(buffer);
        // }
        break;
      }
      case 'n': // loading cubic trajectory
      {
         int dump = 0;
        NU32_ReadUART3(buffer, BUF_SIZE);
        sscanf(buffer, "%d", &Nsamples);
        if (Nsamples > TRAJ_SIZE){
          dump = Nsamples - TRAJ_SIZE;
          Nsamples = TRAJ_SIZE;
        }
        int i;
        for (i = 0; i < Nsamples; i++){
          NU32_ReadUART3(buffer, BUF_SIZE);
          sscanf(buffer, "%f", &ref_pos[i]);
        }
        // dump by reading but not saving
        if (dump){ // if dump is true, basically anything not 0
          for (i = 0; i < dump; i++){
            NU32_ReadUART3(buffer, BUF_SIZE);
          }
          dump == 0;
        }
        // testing by sending back what recieved
        // for (i = 0; i < Nsamples; i++){
        //   sprintf(buffer, "%f\r\n", ref_pos[i] );
        //   NU32_WriteUART3(buffer);
        // }
        break;
      }
      case 'o': // execute trajectory
      {
        set_mode(4); // track
        while (curr_mode() == 4){}; // wait until tracking is done
        sprintf(buffer, "%d\r\n", Nsamples); // let client know how many samples comming
        NU32_WriteUART3(buffer);
        int i;
        for (i = 0; i < Nsamples; i++){
          sprintf(buffer, "%f %f\r\n", ref_pos[i], actual_pos[i]);
          NU32_WriteUART3(buffer);
        }
        break;
      }
      case 'p': // unpower motor
      {
        set_mode(0);
        user_deg = 0; // reset commanded deg
        break;
      }
      case 'q':
      {
        // handle q for quit. Later you may want to return to IDLE mode here. 
        set_mode(0);
        break;
      }
      case 'r':
      {
        switch (curr_mode()){ // 0 = IDLE, 1 = PWM, 2 = ITEST, 3 = HOLD, 4 = TRACK
          case 0: 
          {
            sprintf(buffer, "IDLE\r\n");
            NU32_WriteUART3(buffer);
            break;
          }
          case 1:
          {
            sprintf(buffer, "PWM\r\n");
            NU32_WriteUART3(buffer);
            break;
          }
          case 2:
          {
            sprintf(buffer, "ITEST\r\n");
            NU32_WriteUART3(buffer);
            break;
          }
          case 3:
          {
            sprintf(buffer, "HOLD\r\n");
            NU32_WriteUART3(buffer);
            break;
          }
          case 4:
          {
            sprintf(buffer, "TRACK\r\n");
            NU32_WriteUART3(buffer);
            break;
          }
          default:
          {
            sprintf(buffer, "IDLE\r\n");
            NU32_WriteUART3(buffer);
            break;
          }
        }
      }
      default:
      {
        NU32_LED2 = 0;  // turn on LED2 to indicate an error
        break;
      }
    }
  }
  return 0;
}
