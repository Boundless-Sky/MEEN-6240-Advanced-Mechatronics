#include "encoder.h"
#include <xc.h>

static int encoder_command(int read) {
    // send a command to the encoder chip
    // 0 = reset count to 32,768, 1 = return the count
    // we need this because the timer is an unsigned int from 0 to 2^16 -1
    // so if we were at 0 and turned the encoder negative then it would be keep reading 0
    // thats why we want to reset to 32,768

    SPI4BUF = read;                // send the command
    while (!SPI4STATbits.SPIRBF){;} // wait for response
    SPI4BUF;                       // garbage was transferred, ignore it
    SPI4BUF = 5;                   // write garbage, but the read will have the data
    while (!SPI4STATbits.SPIRBF){;}
    SPI4BUF;                       // need this? check how encoder reads
    return SPI4BUF;
}

int encoder_counts(void) {
    return encoder_command(1);
}

void encoder_reset(void){
    encoder_command(0);
}

void encoder_init(void) {
    // * SEE figure 28.6 for which pins are being used *
    // SPI Initialization for reading from the decoder chip
    // uses a baud of 8Mhz, 16-bit operation
    // sampling on falling edge, and automatic slave detect
    SPI4CON = 0;                // stop and reset SPI4
    SPI4BUF;                    // read to clear the rx receive buffer
    SPI4BRG = 0x4;               // bit rate to 8 MHz, SPI4BRG = 80,000,000/(2*DESIRED) - 1
    SPI4STATbits.SPIROV = 0;    // clear the overflow
    SPI4CONbits.MSTEN = 1;      // master mode
    SPI4CONbits.MSSEN = 1;      // slave select enable
    SPI4CONbits.MODE16 = 1;     // 16 bit mode
    SPI4CONbits.MODE32 = 0;
    SPI4CONbits.SMP = 1;        // sample at the end of the clock
    SPI4CONbits.ON = 1;         // turn SPI on
}

float encoder_deg(void){
    // Quadrature encoder - 
    // x = 4x resoultion
    // N = 256 CPR (Counts per Revolution)
    // 0 - 65535 (2^16 -1) with 32,768 being "zero" position
    // 32,768 = 0 deg
    // EdgeCount/(x*N) * 360 = degree moved
    // EdgeCount*0.352 
    // encodercount - 32,768 so you can get negative
    // then equation. then it will give you negative.
    // again this doesn't account for overflow.
    // we are assuming here that we will never reach overflow
    // i.e 32768/256 = 128 turns before overflow. 
    // see page 523 in NU32 textbook for pic32 datatypes

    long edgecount;
    // counts/counts per revolution * 360 
    // c/256*360 but we have a qudarature encoder so
    // 4 count = 1 pulses
    // since multiply is faster than division we precompute
    // 360/(4*256) ~= 0.352 deg/count
    encoder_counts(); // dump this
    edgecount = 32768 - encoder_counts();
    float deg;
    deg = edgecount * 0.352;
    return deg;
}