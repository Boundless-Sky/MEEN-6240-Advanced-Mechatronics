#include <xc.h>                 // processor SFR definitions
#include <sys/attribs.h>        // __ISR macro
#include "encoder.h"
#include "isense.h"
#include "utilities.h"
#include "NU32.h"
#include "positioncontrol.h"

/* Want an interrupt every 200Hz which is every 0.005 seconds
thus 
80Mhz CPU/64 prescaler arbitrarly chosen * 0.005 = 6250
which period register + 1 = 6250 thus PR = 6249
*/

void posControl_init(void){
    //***200Hz ISR initializiaiton (timer3)
    PR3 = 6249;
    T3CONbits.TCKPS = 6; //prescalar ratio of 64 different for timer1 and timer 2-5
	//T3CONbits.TCS = 0; //peripheral bus clk
	T3CONbits.ON = 1; // enables timer

    //***ISR TIMER 3 _TIMER_3_VECTOR
	IPC3bits.T3IP = 3; //PRIORITY NEEDS TO BE SAME IN FUNCTION
	IPC3bits.T3IS = 0; //SUBPRIORITY
	IFS0bits.T3IF = 0; // clear flag
	IEC0bits.T3IE = 1; // ENABLE

    /* 
    TRISDSET = 0xC --> recall 0xC is 0b1100 and that it index from bit 0
    TRISDCLR = 0x22 --> 0b0010 0010
    TRISDINV = 0x11 --> TRISDINV stands for TRISD invert, see page 43 in textbook for example
    LATFbits.LATF0 = 0  f can be changed out to meet your needs
    PORTx is the same as above
    PORTDbits.RD7
    LATFINV = 0x0003
    */

}




