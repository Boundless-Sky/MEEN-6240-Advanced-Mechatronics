#ifndef __Utilities__H
#define __Utilities__H

#include <xc.h>                 // processor SFR definitions
#include <sys/attribs.h>        // __ISR macro

// 0 = IDLE, 1 = PWM, 2 = ITEST, 3 = HOLD, 4 = TRACK
int mode;
void set_mode(int N);         // set mode
int curr_mode(void);        // returns current mode
void receive_data(double buff, int N);  // recieve N samples to save into data buffers
                                        // during next TRACK or ITEST
void write_data(double buff, int N);    // write data to buffer if N samples not reached
void send_data(double *buff, int N);    // send buffer to client whe N samples been collected


#endif //__Utilities__H