% Author: Justin Ngo, adapted from NU32 book
% Motor Control Project
% client('COM5')
% Reset encoder before  first use
function client(port)
%   provides a menu for accessing PIC32 motor control functions
%
%   client(port)
%
%   Input Arguments:
%       port - the name of the com port.  This should be the same as what
%               you use in screen or putty in quotes ' '
%
%   Example:
%       client('/dev/ttyUSB0') (Linux/Mac)
%       client('COM3') (PC)
%
%   For convenience, you may want to change this so that the port is hardcoded.
   
% Opening COM connection
if ~isempty(instrfind)
    fclose(instrfind);
    delete(instrfind);
end

fprintf('Opening port %s....\n',port);

% settings for opening the serial port. baud rate 230400, hardware flow control
% wait up to 120 seconds for data before timing out
mySerial = serial(port, 'BaudRate', 230400, 'FlowControl', 'hardware','Timeout',120); 
% opens serial connection
fopen(mySerial);
% closes serial port when function exits
clean = onCleanup(@()fclose(mySerial));                                 

has_quit = false;
% menu loop
while ~has_quit
    fprintf('PIC32 MOTOR DRIVER INTERFACE\n\n');
    % display the menu options; this list will grow
    % fprintf('     d: Dummy Command    q: Quit\n');
    fprintf('  a: Read Current Sensor [ADC counts]    b: Read Current Sensor [mA]\n');
    fprintf('  c: Read encoder [counts]               d: Read encoder [deg]\n');
    fprintf('  e: Reset encoder                       f: Set PWM [-100 to 100]\n');
    fprintf('  g: Set current gains                   h: Get current gains\n');
    fprintf('  i: Set position gains                  j: Get position gains\n');
    fprintf('  k: Test current control                l: Go to angle [deg]\n');
    fprintf('  m: Load step trajectory                n: Load cubic trajectory\n');
    fprintf('  o: Execute trajectory                  p: Unpower the motor\n');
    fprintf('  q: Quit client                         r: Get mode\n');
   
    % read the user's choice
    selection = input('\nENTER COMMAND: ', 's');
     
    % send the command to the PIC32
    fprintf(mySerial,'%c\n',selection);
    
    % take the appropriate action
    switch selection
%********* Sample Code **************
%         case 'd'                         % Example Operation
%             n = input('Enter number: '); % get the number to send
%             fprintf(mySerial, '%d\n',n); % send the number
%             n = fscanf(mySerial,'%d');   % get the incremented number back
%             fprintf('Read: %d\n',n);     % print it to the screen
%         case 'x'                         % Example: add 2 integers and
%                                          % return sum to client'

%******** Motor Control Project ***********
        case 'a' % Read current sensor [ADC counts]
            i_counts = fscanf(mySerial, '%d');
            fprintf('The current in ADC counts is: %d \n\n', i_counts);
        case 'b' % Read current sensor [mA]
            i_mA = fscanf(mySerial, '%f');
            fprintf('The current in mA is: %f \n\n', i_mA);
        case 'c' % Read encoder [counts]
            counts = fscanf(mySerial, '%d');
            fprintf('The motor angle is %d counts\n\n', counts);
        case 'd' % Read encoder [deg]
            deg = fscanf(mySerial, '%f');
            fprintf('The motor angle is %f degrees\n\n', deg);
        case 'e' % Reset encoder
            fprintf('Encoder reset complete\n\n');
        case 'f' % Set PWM [-100 to 100]
            n = input('PWM duty cycle [-100 (ccw) to 100 (cw)]: '); %in percent 
            fprintf(mySerial, '%d\n',n); %send the number
%             n = fscanf(mySerial,'%d');   % get the incremented number back
%             fprintf('Read: %d\n',n);     % print it to the screen
        case 'g' % Set current gains
            n = input('Enter your desired Kp current gain [recommended: 1.7 ]: ');
            fprintf(mySerial, '%f\n', n);
            m = input('Enter your desired Ki current gain [recommended: 200 ]: ');
            fprintf(mySerial, '%f\n', m);
        case 'h' % Get current gains
            n = fscanf(mySerial,'%f');   
            m = fscanf(mySerial,'%f');
            fprintf('Current Controller is using, Kp = %f, Ki = %f \n\n',n,m);
        case 'i' % Set position gains
            n = input('Enter your desired Kp position gain [recommended: step 7,cubic 20]: ');
            fprintf(mySerial, '%f\n', n);
            m = input('Enter your desired Ki position gain [recommended: stpe 0,cubic 3]: ');
            fprintf(mySerial, '%f\n', m);
            p = input('Enter your desired Kd position gain [recommended: step 1,cubic 2]: ');
            fprintf(mySerial, '%f\n', p);
        case 'j' % Get position gains
            n = fscanf(mySerial,'%f');   
            m = fscanf(mySerial,'%f');
            p = fscanf(mySerial,'%f');
            fprintf('Current Controller is using, Kp = %f, Ki = %f, Kd = %f \n\n',n,m,p);
        case 'k' % Test current control
            read_plot_matrix(mySerial);
        case 'l' % Go to angle [deg]
            n = input('Enter degree (integer): ');
            fprintf(mySerial, '%d\n', n);
            m = fscanf(mySerial, '%d');
            fprintf('Degree Commanded: %d\n',m);
        case 'm' % Load step trajectory %see genRef how to use 
            A = input('Enter step trajectory: '); %[time, angle; time, angle...]
            b = genRef(A, 'step');
            fprintf(mySerial, '%d\n', length(b)); %number of samples
            for i = 1:length(b)
                fprintf(mySerial, '%f\n', b(i));
            end
            fprintf('Step Trajectory Sent\n\n');
%             for i = 1:500 
%                 data(i) = fscanf(mySerial, '%f');
%             end
%             keyboard;
        case 'n' % Load cubic trajectory
            A = input('Enter cubic trajectory: ');
            b = genRef(A, 'cubic');
            fprintf(mySerial, '%d\n', length(b)); %number of samples
            for i = 1:length(b)
                fprintf(mySerial, '%f\n', b(i));
            end
            fprintf('Cubic Trajectory Sent\n\n');
        case 'o' % Execute trajectory
            trajectory_plot(mySerial);
        case 'p' % Unpower the motor
            fprintf('Motor stopped \n\n');
        case 'q' % Quit client
            has_quit = true;             % exit client
        case 'r' % Get mode
            curr_mode = fscanf(mySerial, '%s');
            fprintf('PIC32 Controller Mode: %s\n\n', curr_mode);
        otherwise
            fprintf('Invalid Selection %c\n\n', selection);
    end
end

end
