#ifndef __isense__H
#define __isense__H

#include <xc.h>                 // processor SFR definitions
#include <sys/attribs.h>        // __ISR macro

#include "NU32.h"          // constants, functions for startup and UART

#define VOLTS_PER_COUNT (3.3/1024)
#define CORE_TICK_TIME 25    // nanoseconds between core ticks
#define SAMPLE_TIME 10       // 10 core timer ticks = 250 ns
#define DELAY_TICKS 20000000 // delay 1/2 sec, 20 M core ticks, between messages

// Use B15 on PIC32 (aka. AN15, pin30) see table 2.2 in book

/* About: This module owns the ADC peripheral, used to sense the motor current. The interface
isense.h should provide functions for a 1 time setup of the ADC, to provide the ADC value in 
ADC counts (0-1023), and to proide the ADC value in terms of milliamps of current through the
motor */

/* ::See page 478 for more details *(star is the one with adjusted value to 6 volts from 24v)::
    1. 390 ohs for R3
    We aren't given motor resistance but we are given 
    peak current from the data sheet. i_max = 2.79A
    3. V_max = 15milli ohms (what was on the current sense board max9918)* 2.79A
        V_max = 15*10^-3*2.79 = 0.042V
        *V_max = 0.015*0.7 = 0.011V
    4. choosing R1 and R2 so current sense amp gain G = 1 + R2/R1
        approximatly satisfies 1.65 V = G * Vmax 
        choose R1 and R2 to be in 10^4 - 10^6
        G = 1.65(from volt divider of 3.3V Vin)/Vmax = 39.3
        therefore R2 = 38*R1 
        limited on resistors i choosed
        R2 = 10k ohms
        R1 = 270 ohms
        with G = 38
        *(R2 = 10k ohms
        R1 = 100 ohms
        with G = 99 , ideally we want 157 ohms to get max 3.3 range)
    5. fc = 1/(2pi*R*C) closest i was able to get is 
        R = 2.2k
        C = 220nF
        fc ~= 329 hz 
        which is close to the desired 200 hz to suppresses high-freq components
        due to 20 khz PWM.
    6. Testing - need high current resistors
    we have 6v battery (6.35v)
    R0 (ohms)     | Expected (mA) | measured(mA) | Sensor(V) | ADC counts
    56 (to RS+)   | 107           |    108.5     |  1.81     | 511
    open circuit  | 0             |     0        | 1.63      | 459
    56 (to RS-)   | -107          |    -108.4    | 1.46      | 413
    *Motor Stall  |               |              | 2.68      | 710
    
    stall gives me ~ 2v
    no load gives me ~ 1.65v
    but this is a 24vdc motor... but we are using 6 volts... so peak
    current is a lot less than what was given in datasheet. so max current should be 
    2.79/4 (4 is from 24/6 = 4) = 0.7A
    
    From matlab this gives y = 2.2*x - 1010 where y = mA and x = ADC counts
     */



void isense_init(void);
unsigned int avg_i_count(void);
float avg_i_mA(void);


#endif //__isense__H