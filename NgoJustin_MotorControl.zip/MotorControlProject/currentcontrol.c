#include <xc.h>                 // processor SFR definitions
#include <sys/attribs.h>        // __ISR macro
#include "encoder.h"
#include "isense.h"
#include "utilities.h"
#include "NU32.h"
#include "currentcontrol.h"

/* Want an interrupt every 5kHz which is every 0.0002 seconds
thus 
80Mhz CPU/64 prescaler arbitrarly chosen * 0.0002 = 250
which period register + 1 = 250 thus PR = 249

80000000/4 * 0.00005 = 1000 => PR2 = 999 with prescaler of 4
*/

void currControl_init(void){
    //***5kHz ISR initializiaiton (timer1)
    PR1 = 249;
    T1CONbits.TCKPS = 2; //prescalar ratio of 64 different for timer1 and timer 2-5
	T1CONbits.TCS = 0; //peripheral bus clk
	T1CONbits.ON = 1; // enables timer

    //***ISR TIMER 1
	IPC1bits.T1IP = 6; //PRIORITY NEEDS TO BE SAME IN FUNCTION
	IPC1bits.T1IS = 0; //SUBPRIORITY
	IFS0bits.T1IF = 0; // clear flag
	IEC0bits.T1IE = 1; // ENABLE

    //****20 kHz PWM Signal (timer & output compare) Code sample 9.1
    // PIN OC1 is D0 on breakout board TABLE 2.2
    T2CONbits.TCKPS = 2; // Timer2 prescaler N=4 (1:4)
    PR2 = 999; // period = (PR2+1) * N * 12.5 ns = 100 us, 20 kHz
    TMR2 = 0; // initial TMR2 count is 0
    OC1CONbits.OCM = 0b110; // PWM mode without fault pin; other OC1CON bits are defaults
    OC1RS = 0;//250; // duty cycle = OC1RS/(PR2+1) = 25% 
    OC1R = 0;//250; // initialize before turning OC1 on; afterward it is read-only
    T2CONbits.ON = 1; // turn on Timer2
    OC1CONbits.ON = 1; // turn on OC1

    // change duty cycle with 
    // OC1RS = 1000 or something this is 100 percent pwm

    //***digital output motor direction (high or low)
    // using pin D6 or RD6 see table 2.2, 
    // see code sample 7.1 book and chapter 12 in datasheet
    TRISD = 0x0FBF; // set as digital output pin 6 setting it 0
    //TRISD = 0x0F3F; // set digital pins 6 and 7 as output d6/d7 on break out board
    /* 
    TRISDSET = 0xC --> recall 0xC is 0b1100 and that it index from bit 0
    TRISDCLR = 0x22 --> 0b0010 0010
    TRISDINV = 0x11 --> TRISDINV stands for TRISD invert, see page 43 in textbook for example
    LATFbits.LATF0 = 0  f can be changed out to meet your needs
    PORTx is the same as above
    PORTDbits.RD7
    LATFINV = 0x0003
    */

}





