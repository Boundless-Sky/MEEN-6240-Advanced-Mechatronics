#ifndef __Encoder__H
#define __Encoder__H

#include <xc.h>                 // processor SFR definitions
#include <sys/attribs.h>        // __ISR macro

void encoder_init(void);        // initialize the encoder do this first
int encoder_counts(void);       // read encoder
void encoder_reset(void);       // reset encoder to middle
float encoder_deg(void);

// ****  function to deal with encoder run over ****
// but since this is a 16 bit encoder it would need some odd 30
// turns before it overflowed.... so.... nah. not going to do it
//need while loop after need 2nd buffer reading. 


#endif //__Encoder__H