#include "utilities.h"


void set_mode(int N){
    mode = N;
}         
int curr_mode(void){
    return mode;
}   
void receive_data(double buff, int N);  
void write_data(double buff, int N);    
void send_data(double *buff, int N);  