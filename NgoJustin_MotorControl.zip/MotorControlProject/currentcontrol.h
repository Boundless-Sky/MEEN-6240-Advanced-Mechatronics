/* This module implements the 5kHz current control loop. It owns a timer
to implement the fixed-frequency control loop, an output compared and another timer to
implement a PWM signal to the H-bridge, and one digital output controlling the motor's 
direction. (see chapter 27 on DRV 8835)

Depending on the PIC32 operationg mode, the current controller either brakes
the motor(IDLE mode), implements a constant PWM (PWM mode), uses the 
current control gains to try to provicd a current speciried by the position controller 
(HOLD or TRACK mode), or uses the current control gains to track a 100 hz +- 200mA
square wave reference (ITEST mode). The interface currentcontrol.h should

provide functions to 
initialize the module, 
recieve a fixed PWM command in the range [-100, 100], recieve a desired current
( from the position control module), 
recieve current control gains,
and provide the current control gains */

#ifndef __CurrControl__H
#define __CurrControl__H

#include <xc.h>                 // processor SFR definitions
#include <sys/attribs.h>        // __ISR macro
#include "encoder.h"
#include "isense.h"
#include "utilities.h"
#include "NU32.h"

void currControl_init(void);


#endif //__CurrControl__H