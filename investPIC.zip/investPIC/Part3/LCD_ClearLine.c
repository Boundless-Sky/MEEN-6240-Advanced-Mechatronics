#include "NU32.h"
#include "LCD.h"

void LCD_ClearLine(int ln) {
    char clearline[100] = {};
    if (ln == 0) {
        LCD_Move(0,0);
        LCD_WriteString(clearline);
    } 
    if (ln == 1){
        LCD_Move(0,0);
        LCD_WriteString(clearline);
    }
}