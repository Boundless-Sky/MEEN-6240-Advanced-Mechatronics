//helper.h
#ifndef helper_H
#define helper_H

#include "NU32.h"
#include <stdio.h>  

#define MAX_YEARS 100   
#define MSG_LEN 100

typedef struct {
  double inv0;                    
  double growth;                  
  int years;                      
  double invarray[MAX_YEARS+1];   
} Investment;  




#endif // helper_H