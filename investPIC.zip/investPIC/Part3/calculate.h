#ifndef calculate_H
#define caluclate_H

#include "helper.h"

void calculateGrowth(Investment *invp);

#endif // calculate_H