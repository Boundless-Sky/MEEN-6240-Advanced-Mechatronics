#ifndef io_H
#define io_H

#include "helper.h"

void sendOutput(double *arr, int yrs);
int getUserInput(Investment *invp);

#endif // io_H

