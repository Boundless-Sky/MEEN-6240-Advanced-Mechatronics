//helper.h
#ifndef helper_H
#define helper_H

#define MAX_YEARS 100   
#define MSG_LEN 100

typedef struct {
  double inv0;                    
  double growth;                  
  int years;                      
  double invarray[MAX_YEARS+1];   
} Investment;  

void sendOutput(double *arr, int yrs);
int getUserInput(Investment *invp);
void calculateGrowth(Investment *invp);

#endif // helper_H